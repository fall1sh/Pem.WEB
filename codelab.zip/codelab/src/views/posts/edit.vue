<script setup> 
 
</script> 
 
<template> 
 <div class="container mt-5 mb-5"> 
     <div class="row"> 
         <div class="col-md-12"> 
             <div class="card border-0 rounded shadow"> 
                 <div class="card-body"> 
                     HALAMAN POST EDIT 
                 </div> 
             </div> 
         </div> 
     </div> 
 </div> 
</template> 